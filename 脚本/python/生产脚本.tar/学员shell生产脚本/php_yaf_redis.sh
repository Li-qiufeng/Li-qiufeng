#!/bin/bash
date_now=`date +"%Y-%m-%d %H:%M:%S"`
php_yaf_redis(){
  cd /resource/
  tar -zvxf m4-1.4.9.tar.gz
  cd /resource/m4-1.4.9/
  ./configure && make && make install
  if [ $? != 0 ];then
    echo "php_yaf install faild !"
    exit
  fi

#  cd /resource/ && \
#  tar -xzvf Data-Dumper-2.154.tar.gz && \
#  cd /resource/Data-Dumper-2.154/ && \
#  perl Makefile.PL && \
#  make && make install
#  if [ $? != 0 ];then
#    echo "php Date_Dumper install faild !"
#  fi
  rpm -ivh /resource/rpmBao/php-fpm/perl-Data-Dumper-2.145-3.el7.x86_64.rpm
	
  cd /resource/ && \
  tar -zvxf autoconf-2.62.tar.gz && \
  cd /resource/autoconf-2.62/ && \
  ./configure && make && make install
  if [ $? != 0 ];then
    echo "php autoconf install faild !"
    exit
  fi  

  cd /resource/ && \
  tar zxvf yaf-3.0.5.tgz && \
    cd /resource/yaf-3.0.5 && \
    /usr/local/php7/bin/phpize && \
    ./configure --with-php-config=/usr/local/php7/bin/php-config/php-config && \
	make && make install
  if [ $? != 0 ];then
    echo "php yaf install faild !"
    exit
  fi
	
	cd /resource/ && \
	tar zxvf phpredis-3.1.3RC2.tar.gz && \
    cd /resource/phpredis-3.1.3RC2 && \
    /usr/local/php7/bin/phpize && \
    ./configure --with-php-config=/usr/local/php7/bin/php-config/php-config && \
	make && make install
  if [ $? != 0 ];then
    echo "php phpredis install faild !"
    exit
  fi
##fileinfo##
  cd /resource/php-7.1.19/ext/fileinfo/ && \
  /usr/local/php7/bin/phpize && \
  ./configure --with-php-config=/usr/local/php7/bin/php-config/php-config && \
  make && make install
  if [ $? -ne 0 ];then
    echo "php fileinfo install faild !"
  fi
	
	\cp -f /resource/startup/php.ini /usr/local/php7/etc/
	\cp -Rf /resource/startup/php-fpm.d/ /usr/local/php7/etc/
	cd /resource/startup/install
}
php_yaf_redis && \
echo "php_yaf_redis installed is complete"
echo "$date_now php_yaf_redis installed is complete" >> /var/log/anzhuang.log
