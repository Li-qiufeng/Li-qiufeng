#!/bin/bash
set -o errexit
date_now=`date +"%Y-%m-%d %H:%M:%S"`
php_install(){
  
## php 依赖包安装
# freetype
rpmDir1="/resource/rpmBao/php-fpm/freetype"
# libcurl
rpmDir2="/resource/rpmBao/php-fpm/libcurl"
# libjpeg
rpmDir3="/resource/rpmBao/php-fpm/libjpeg"
# libmcrypt
rpmDir4="/resource/rpmBao/php-fpm/libmcrypt"
# libxml2
rpmDir5="/resource/rpmBao/php-fpm/libxml2"
# openssl
rpmDir6="/resource/rpmBao/php-fpm/openssl"
for rpmDir in $rpmDir{1..6}
do
	rpm -ivh $rpmDir/*.rpm --nodeps --force
	if [ $? != 0 ];then
		echo "rpm install faild"
		echo " rpm包位置$rpmDir"
		exit
	fi
done

#  mkdir /usr/local/php7
#  mkdir /usr/local/php7/etc
  mkdir /usr/local/php7/etc/php.d -p
#  mkdir /usr/local/php7/bin
  mkdir /usr/local/php7/bin/php-config -p
  
  cd /resource/ && \
  tar zvxf php-7.1.19.tar.gz && \
  cd /resource/php-7.1.19 && \
  ./configure --prefix=/usr/local/php7 \
      --with-config-file-path=/usr/local/php7/etc \
      --with-config-file-scan-dir=/usr/local/php7/etc/php.d \
      --with-fpm-user=www \
      --with-fpm-group=www \
      --with-mcrypt=/usr/include \
      --with-mysqli \
      --with-pdo-mysql \
      --with-openssl \
      --with-gd \
      --with-iconv \
      --with-zlib \
      --with-gettext \
      --with-curl \
      --with-png-dir \
      --with-jpeg-dir \
      --with-freetype-dir \
      --with-xmlrpc \
      --with-mhash \
      --enable-fpm \
      --enable-xml \
      --enable-shmop \
      --enable-sysvsem \
      --enable-inline-optimization \
      --enable-mbregex \
      --enable-mbstring \
      --enable-ftp \
      --enable-gd-native-ttf \
      --enable-mysqlnd \
      --enable-pcntl \
      --enable-sockets \
      --enable-zip \
      --enable-soap \
      --enable-session \
      --enable-opcache \
      --enable-bcmath \
      --enable-exif \
      --disable-fileinfo \
      --disable-rpath \
      --disable-ipv6 \
      --disable-debug \
      --without-pear
  if [ $? -ne 0 ];then
          echo "## php ./config faild ! ##"
          exit
  fi
  make && make install
  echo "export PATH=\$PATH:/usr/local/php7/bin" >> /etc/profile
  source /etc/profile
  
  cd /resource/php-7.1.19/ && \
  \cp php.ini-production /usr/local/php7/etc/php.ini && \
  \cp /usr/local/php7/etc/php-fpm.conf.default /usr/local/php7/etc/php-fpm.conf && \
  \cp /usr/local/php7/etc/php-fpm.d/www.conf.default /usr/local/php7/etc/php-fpm.d/www.conf
  
  mkdir -p /var/log/php-fpm/
  mkdir -p /data1/www/htdocs && \
  cd /resource/startup/install

}

php_install && \
echo "php installed is complete"
echo "$date_now php installed is complete" >> /var/log/anzhuang.log
