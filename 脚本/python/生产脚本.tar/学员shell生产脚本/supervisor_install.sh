#��װsupervisor
date_now=`date +"%Y-%m-%d %H:%M:%S"`
supervisor_install(){
	mkdir /var/run/supervisor
	touch /var/run/supervisor/supervisor.sock
	touch /var/log/supervisord.log
	touch /tmp/supervisord.pid
	mkdir /etc/supervisord.d
	mkdir /var/log/supervisord

	services=(kafka es influxdb redis mysql mongodb nginx supervisor)
	for i in ${services[@]}
	do
		touch /var/log/supervisord/$i.{info,error}.log
	done

	#touch /var/log/supervisord/kafka.info.log
	#touch /var/log/supervisord/kafka.error.log
	#touch /var/log/supervisord/es.info.log
	#touch /var/log/supervisord/es.error.log
	#touch /var/log/supervisord/influxdb.info.log
	#touch /var/log/supervisord/influxdb.error.log
	#touch /var/log/supervisord/redis.info.log
	#touch /var/log/supervisord/redis.error.log
	#touch /var/log/supervisord/mysql.info.log
	#touch /var/log/supervisord/mysql.error.log
	#touch /var/log/supervisord/mongodb.info.log
	#touch /var/log/supervisord/mongodb.error.log
	#touch /var/log/supervisord/nginx.info.log
	#touch /var/log/supervisord/nginx.error.log
	#touch /var/log/supervisord/supervisor.info.log
	#touch /var/log/supervisord/supervisor.error.log

	chmod 777 /var/log/supervisord
	
    mkdir -p /var/log/supervisor && \
    mkdir -p /var/run/supervisord
	
	\cp -f /resource/startup/supervisord.conf /etc
	\cp -Rf /resource/startup/supervisord.d /etc
        mkdir -p /var/supervisor
        touch /var/supervisor/supervisor.sock
        tar -xzvf /resource/supervisor.tar.gz -C /resource/
	sleep 1
        cd  /resource/supervisor/setuptools-0.6c11/
        python setup.py build && \
        python setup.py install  && \
        cd /resource/supervisor/meld3-1.0.2/ && \
        python setup.py install && \
        cd /resource/supervisor/supervisor-3.3.2/ && \
	python setup.py install
	\cp /resource/startup/supervisord.service /lib/systemd/system/        
}

supervisor_install && \
echo "$date_now supervisor installation is complete" |tee  /var/log/anzhuang.log

