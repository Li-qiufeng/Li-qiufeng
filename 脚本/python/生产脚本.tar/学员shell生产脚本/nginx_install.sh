#!/bin/bash
date_now=`date +"%Y-%m-%d %H:%M:%S"`

nginx_pre_install(){
## 安装nginx依赖包
## gcc gcc-c++
nginxDir1="/resource/rpmBao/nginx/gcc"
## openssl openssl-devel
nginxDir2="/resource/rpmBao/nginx/openssl"
## pcre-devel
nginxDir3="/resource/rpmBao/nginx/pcre-devel"

for nginxDir in $nginxDir{1..3}
do
        rpm -ivh $nginxDir/*.rpm --nodeps --force
        if [ $? != 0 ];then
                echo "rpm install faild"
                echo "rpm包位置: $nginxDir"
                exit
        fi
done
}


nginx_install(){
  groupadd -r www && \
  useradd -M -s /sbin/nologin -r -g www www && \
  groupadd -r nginx && useradd -r -g nginx -s /bin/false -M nginx

  cd /resource/nginx && \
  tar -zxvf nginx-1.13.3.tar.gz && \
  cd /resource/nginx/nginx-1.13.3/ && \
  ./configure --prefix=/usr/local/nginx \
    --with-http_stub_status_module \
    --user=www --group=www \
    --error-log-path=/var/log/nginx/error.log \
    --http-log-path=/var/log/nginx/access.log \
    --pid-path=/var/run/nginx.pid \
    --with-pcre \
    --with-http_ssl_module \
    --without-mail_pop3_module \
    --without-mail_imap_module \
    --with-http_gzip_static_module \
    --with-stream && \
  make && make install
  if [ $? != 0 ];then
  	echo "nginx 编译失败！！！"
  	exit
  fi

    \cp -f /resource/startup/nginx.conf /usr/local/nginx/conf/
    \cp -Rf /resource/startup/conf.d /usr/local/nginx/conf/
}
nginx_pre_install && \
echo "$date_now nginx_pre_install installation is complete" |tee /var/log/anzhuang.log

nginx_install && \
echo "$date_now nginx_install installation is complete" |tee /var/log/anzhuang.log
